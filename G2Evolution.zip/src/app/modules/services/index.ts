/* ......All service Components Export Features....... */

export * from './pages/service/service.component'