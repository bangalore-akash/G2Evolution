export const environment = {
  production: true,
  server_url: 'http://162.144.75.185/~garudainfotech/g2_evolution'
};
