import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  enquiryForm : FormGroup;
  submitted: boolean = false;
  message: any;
  error: any;
  
  constructor(
    private formBuilder: FormBuilder,
    private enquiryService: ApiService,
    private spinner: NgxSpinnerService
  ) { 
    this.enquiryForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      subject: [""],
      mobile: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      message: ["", Validators.required ],
    })
  }
  get f() {
    return this.enquiryForm.controls;
  }

  enquiry(){
    this.submitted = true;
    if (this.enquiryForm.invalid) {
     return;
   }
   this.spinner.show();
    var Formelement = this.enquiryForm.value;
    this.enquiryService.post('/api/contact_mail/send',Formelement).pipe(
      tap(response =>{
        console.log(response);
        Swal.fire('success', response.message, 'success')
        this.message = response.message;
        if(response.status == "success" || response.status == "failure" ){

        }
      }),
      finalize(() => this.spinner.hide()),
      catchError(error => of(this.error = error, Swal.fire('error', 'Internal Server Error', 'error'),console.log(error)))
    ).subscribe();
   }

  ngOnInit() {
  }


}
