import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lets-work',
  templateUrl: './lets-work.component.html',
  styleUrls: ['./lets-work.component.css']
})
export class LetsWorkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
